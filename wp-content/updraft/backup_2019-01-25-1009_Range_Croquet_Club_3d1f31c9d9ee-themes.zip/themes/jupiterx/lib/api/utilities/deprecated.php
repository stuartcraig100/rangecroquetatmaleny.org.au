<?php
/**
 * Deprecated utility functions.
 *
 * @package JupiterX\Framework\API\Utilities
 */

// Add the deprecated functions here.
